# Synopsis

- Player is swept from the draft of a car and begins to float through the streets.

# Objectives

- Semi-trucks and cars make wind unstable and player controls harder.&#x20;
- squirrels in trees planted on the roadside try to grab at the player.&#x20;
- Hail/thunderstorm makes the player need to move away from cars and dodge falling hail.&#x20;
- End the level with the hail/thunderstorm ending and a semi creating a draft of wind blowing the character back into a suburban neighborhood.&#x20;

# Location(s)

- Street
- Possibly some trees or canopies to move between.&#x20;
- <br>
  <br>

# Level walkthrough

<br>
