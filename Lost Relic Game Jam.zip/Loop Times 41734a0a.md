1. 1:37:290 to 3:14:589
2. I guess you don't have to care about the last one but that's where the loop should start over. At 1:37:290
