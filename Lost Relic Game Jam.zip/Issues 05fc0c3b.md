\- animation going down into the tree is sometimes buggy. (solution might be to remove the animation, or work on it)

&#x20;\- health / stamina isn't implemented yet, so the user will be able to get stuck more easily

&#x20;\- checkpoints need to be made so the user can start back at natural starting points.&#x20;

\- More loading / deleting game objects to clean up rendering space on the terrain.

- fix speed

<br>

Level 2

- fix speed
- Add more wind tunnels
- \- still need wall barriers or a way to prevent player from moving past tree line.&#x20;
- \- loose dandelions should be around the player, but not in front of.&#x20;
- \-Check how stamina works when that mechanic for death is added.
