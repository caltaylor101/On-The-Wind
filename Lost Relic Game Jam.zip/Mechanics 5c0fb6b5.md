# Physics 

## Movement

### Wind

Space bar drops seed quickly.&#x20;

<br>

### Animals

## Objects

### ...

## Actions

### Combat

...

### interacting with objects

...

### Talking

...

### Reading

...\
