# Synopsis

Player emerges from the forest with less seeds around them as before. They find themselves floating towards a suburban area. The player has a gust of wind blow them through the back yards.&#x20;

# Objectives

- dodge wind from blowers.&#x20;
- Move between fences and try to keep height.
- Things that can grant height are when someone is pointing a blower up, possibly a fire pit or barbeque updraft.&#x20;
- Objects to dodge could be a frisbee, boomerang, or kite.&#x20;
- Last level could be a quick succession through chain linked fences where the player needs to reflexively make it through them. Once the player makes it to the street they are swept away by the draft of a car.&#x20;

# Location(s)

- back yards
- trampoline
  <br>

# Level walkthrough

...
