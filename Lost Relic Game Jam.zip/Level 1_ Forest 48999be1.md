# Synopsis

Child blows a dandelion which caused the main character, a seed, to be blown away into the wind. We find the main character in a forest level.&#x20;

# Objectives

- Possible collectables?&#x20;
- Interaction with other seeds?&#x20;
- Boosts
- End of the level shows the main character flying towards an opening in the trees with other seeds. A bird swoops down and eats a seed to the right of the main character. Dodge the bird as seeds around you get eaten.&#x20;

# Location(s)

Forest that is bright and green.&#x20;

# Level walkthrough

...
