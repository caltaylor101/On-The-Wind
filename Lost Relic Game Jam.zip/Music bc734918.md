1. Forest level&#x20;
2. Backyard Level&#x20;
3. Streets level&#x20;
4. Lawn level
