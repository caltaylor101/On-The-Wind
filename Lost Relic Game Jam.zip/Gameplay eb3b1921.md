# Game progression

## Movement

### Wind

Visualization:&#x20;

Objects: Use focus and blur to highlight interactive objects. For specific parts of an object use striking colors. (IE a large red button on a gray lawn blower)

### Animals

<br>

## Floaty Dandelion Seed

- Slight particle effects for large movement.
- <br>

# Objectives

Move the seed to the right as much as possible using objects, wind, etc.

<br>

# Camera Use

Because a dandelion seed is TINY compared to basically everything, the player's vision will have to be quite limited. We'll have to use zoom quite a bit. This will also help with making sure players do not interact with objects before they need to.\
IE:&#x20;

- When the dandelion seed is just flying on the wind, we don't show much except the background. A good time for some background motion or maybe an opportunity to add gameplay where the player controls the seed so it doesn't hit things.
- When the dandelion seed lands on a dog, the camera zooms out to show interactable objects.

# Puzzle Elements

Examples:

- A lawn blower laying on the ground next to some lumber. The player has to tip over the lumber to make a ramp to make the wind go upwards from the lawn blower.
- The seed lands on a dog. Tip over a bone on a table to make the dog move.
