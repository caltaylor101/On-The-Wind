![unknown (1).png](<files/9c3823c9-8186-4cb9-b124-f0700cd59108/unknown (1).png>)

![bokeh_blur_nature_1000px.jpg](files/c48f2389-14f9-422a-9367-d8be7266ee5d/bokeh_blur_nature_1000px.jpg)

# Working title (TBD)

Pollinator

Field of Flowers

Bee Factory

<br>

# Elevator pitch

1. Main character is a speck of pollen, or dandelion seed.&#x20;
   1. The goal of the game would be to navigate through wind obstacles to get to a flower at the end of the level.&#x20;
   2. Other obstacles like birds can get in the way, or maybe we need to attach to an insect like a bee to get further in a platformy manner.&#x20;
   3. It relates to the theme by pollen attaching to things to connect to a flower at the end.&#x20;

# Concept&#x20;

## Overview&#x20;

- **Genre:** Linear (Platformer?)
- **Target audience:**
  - **Age:** G
  - **Gender:** Male/Female
- **Monetization:** Free, maybe make it an app later.
- **Platforms & system requirements:** &#x20;
  - WebGL
  - Windows/Mac builds

## Theme and setting&#x20;

Connection:&#x20;

The movement of pollen to flowers can show the connection that all plants have. This can also help create levels where connection is important in moving to the next levels and to the final level.&#x20;

## Story

1. &#x20;A dandelion is blown by a child.
2. The player follows a dandelion seed as it goes through a suburban neighborhood.
   1. The player interacts with objects to push the dandelion seed to its destination.
3. The dandelion seed lands on a lawn.
4. The game ends with a scene where the dandelion seed has grown is blown by an elder.

# Project scope

## Our team

- **Dev:** [Cody Night](https://app.nuclino.com/users/d07463cc-3aac-4574-9a5b-055b09cbbcb4?mId=OgHRyrf3) (caltaylor101), [Alexsey Zh](https://app.nuclino.com/users/e6a7aa62-f24d-4bdd-820f-892b90dccdbb?mId=kkgc7fBa) (Zerus), [Leo Ryoo](https://app.nuclino.com/users/1f3ab971-2965-45ba-9ef5-7f8ceae1a675?mId=OmWVO030) (Meron)
- **Design:**&#x20;
- **Art: [Jesse Marion](https://app.nuclino.com/users/1eaba8a8-e232-444e-8d06-fbd17661bb1c?mId=g27yJRjV)**
- **QA: **
- Audio: [bright bone](https://app.nuclino.com/users/a68341d3-ce47-4412-864d-d9b3ca73c9ea?mId=4HyLG8EK)

##

## Timeline

- Level 1 - 3 completed between 6/10 - 6/12. Most of the bones of the game are there.&#x20;
- Modifications, features, and polishing done through 6-12 - 6-19
- Testing and last fixes 6-19 - 6-20.&#x20;

##

---

*Artwork credit:* [*Stephane Wootha Richard*](https://commons.wikimedia.org/wiki/User:Artofwootha)

<br>
