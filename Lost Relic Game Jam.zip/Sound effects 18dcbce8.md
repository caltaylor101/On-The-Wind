1. Wind tunnel sound
2. &#x20;Bird swoop swoosh
3. &#x20;Light background wind
4. &#x20;Gentle wind push w/ leaf rustles maybe
5. &#x20;Mushroom sound (my assumption is low note?)
6. Bird noises (something background to add)&#x20;
7. Bird screech or squawk (for the ending 1st level boss)
8. **Trees brustling (very low priority, might be nice for the intro and other areas)**
9. &#x20;**Seed pickup**&#x20;
