# Theme: Connection

<br>

# Inspirational Games

- Unraveled: [d53ed503-6d2f-4510-9cf1-697a0cf72a33.png](files/09ee5176-3d83-4253-81bf-2fc83ad62cf5/d53ed503-6d2f-4510-9cf1-697a0cf72a33.png) (game about being connected to each other by a string)
- Legend of Zelda (Link's connection to time?)&#x20;
- Pikmin
- <br>

# Ideas

1. Main character is a bird of prey. (maybe dragons instead)
   1. The goal of the game would be to find prey, attack it, then bring it back to the nest to feed baby chicks.&#x20;
   2. Skills could be added once the chicks are raised, and the strongest chick leaves the nest to start its own.&#x20;
   3. This could be strength to lift bigger prey, reduce chick hunger, etc.&#x20;
   4. The main character is connected to the nest/offspring.&#x20;
2. Main character is a speck of pollen.
   1. The goal of the game would be to navigate through wind obstacles to get to a flower at the end of the level.&#x20;
   2. Other obstacles like birds can get in the way, or maybe we need to attack to an insect like a bee to get further.&#x20;
   3. It relates to the theme by pollen attaching to a flower.&#x20;
3. Main character is a ghost waking up above their body that is passed out / half dead.&#x20;
   1. The goal of the game would be keeping the character's body safe by defending against threats.&#x20;
   2. This could be by using spirit power to throw rocks/sticks at incoming predators. Taking time to sharpen sticks or create tools. Final boss could be a grizzly bear.&#x20;
   3. Relates to the theme by soul's connection to body.&#x20;
4. Main character would be a robot holding a gun with electric ammo.&#x20;
   1. The main character is an AI attempting to shutoff a wireless network that put many robots from their town under control.&#x20;
   2. The main character would shoot a bullet, then they would need to activate a electric charge in the bullet to create an electrical explosion. The bullet would move slow enough for the player to track, and when the player clicks again it would pulse electric current to a radius around the bullet.&#x20;
   3. Theme relation could be electrical connection through bullet.&#x20;
5. Main character is lit from a match and dropped.&#x20;
   1. The goal of the game would be trying to spread as much fire as possible before it rains.
   2. The level would be navigating through dry grass, using wind to hop to other areas, maybe create an explosion with a gas can. The goal would be to get hot enough to start a forest fire. Example, if you lit 30% of the level, maybe the fire is only 500 degrees and isn't hot enough to start a forest fire.&#x20;
   3. Theme is the connected burn strength of fire.&#x20;
6. Main character is a rain drop falling from a cloud.&#x20;
   1. On their way down they collect more raindrops to get larger and larger.&#x20;
   2. The objective of the game could be to try to break a damn in a river in a flash flood, maybe put out a forrest fire, etc.&#x20;
   3. Theme is connecting water.&#x20;
7. Main character is a small flame, starts off small and weak.&#x20;
   1. Navigate teh flame through obstacles to get to a fireplace, fire pit, or mount of logs.&#x20;
   2. Obstacles could be rain drops, snowflakes, muddy puddles.&#x20;
   3. A boss could be giant snowman
8. Main character is a word&#x20;
   1. Think of madlibs or cards against humanity, but in a 3d setting.&#x20;
   2. The player takes on the form of a "word", floats around town, and find sentences to settle in. They change to a different words and keep repeating the cycle. They do this on a timer and once time is up they're shown what sentences they've made and how that influenced other parts of the town.
      1. The place a player can settle could be a billboard, a person's thoughts, a piece of literature, anything with writing in it.
   3. Theme is connections through words.
9. Main character is a dungeon master
   1. Think of FNAF, where the player is stuck in a room with controls and cameras, but the player has switches and levels that change parts of a dungeon adventurers are going through.&#x20;
   2. The player has limited energy and is trying to keep a person or a group of people from entering their control room. The theme is interchangeable. (a hikikomori avoiding people, a dungeon master avoiding heroes). Objective is to survive a certain duration.
   3. Theme is connections through rivalry/opposed goals.

      &#x20;
