# Synopsis

Player made it through the hail/thunderstorm, the sun is coming back out and they find themselves moving towards a lawn.&#x20;

# Objectives

- Figure out the target speed necessary to make a landing in the perfect spot.&#x20;
- This could be some type of rhythmic input, or way to notify the player to land.&#x20;

# Location(s)

- Suburban area focusing on front lawns.&#x20;
  <br>

# Level walkthrough

<br>
