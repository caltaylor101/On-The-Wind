# Backstory

...

# Personality

...

# Appearance

...

# Special abilities

...
