## Environment

![7acb80ce-f074-43f3-89bc-cb693194a151.png](files/2084fd04-d323-4dc4-99f8-4c0e28e5e517/7acb80ce-f074-43f3-89bc-cb693194a151.png)

![a4485117-6a5e-4b05-9193-610a0adb27b0.png](files/96d7dd79-845a-4a0f-800a-e3fe0e1dfa3f/a4485117-6a5e-4b05-9193-610a0adb27b0.png)

![b0af5c39-8db9-4c86-9d2a-5cfca6004bb6.png](files/8d4f4565-943b-4409-8321-e4485a207843/b0af5c39-8db9-4c86-9d2a-5cfca6004bb6.png)

<br>

<br>

# Locations

## The imperial capital

![0384f2b8-3a0b-4475-877e-ded4d962b8af.png](files/e3ee0ecf-46a4-4af5-b4e5-96ea94decc7e/0384f2b8-3a0b-4475-877e-ded4d962b8af.png)
![92b8b104-9e4e-4fe6-9a07-2b6bf9403e72.png](files/cd9fcf8d-e82d-4582-bc5f-62148c0ea4ef/92b8b104-9e4e-4fe6-9a07-2b6bf9403e72.png)
![8cce72d4-d68e-4d45-9f6b-382db4914ccd.png](files/f0d97865-9ac0-4623-a9c1-139d6ad608f2/8cce72d4-d68e-4d45-9f6b-382db4914ccd.png)

![b0600132-0fb1-4154-bcaf-7048ebb990da.png](files/dccdf485-cc07-4112-aeaf-5e09ae608cf8/b0600132-0fb1-4154-bcaf-7048ebb990da.png)
![4ac9d8e9-9f8f-46e9-a374-6a7261667e8f.png](files/7cfd3786-fe33-48f6-9ffa-39afd0d62fb8/4ac9d8e9-9f8f-46e9-a374-6a7261667e8f.png)

## Secondary locations

### Location #1

...

### Location #2

...

### Location #3

...

# Characters

## Character #1

...

## Character #2

...

## Character #3

...

---

*Artwork credit:* [*David Revoy*](https://commons.wikimedia.org/wiki/User:Deevad "User:Deevad - Wikimedia Commons")
